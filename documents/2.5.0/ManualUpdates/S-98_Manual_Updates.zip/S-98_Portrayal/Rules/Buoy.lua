
function Buoy(feature, featurePortrayal, contextParameters)
    local viewingGroup
    
    if feature.PrimitiveType == PrimitiveType.Point then    
        viewingGroup = 27010

        if contextParameters.RadarOverlay then
            featurePortrayal:AddInstructions('ViewingGroup:27010;DrawingPriority:24;DisplayPlane:OverRadar')
        else
            featurePortrayal:AddInstructions('ViewingGroup:27010;DrawingPriority:24;DisplayPlane:UnderRadar')
        end
        
        featurePortrayal:AddInstructions('PointInstruction:BCNDEF13')

        if feature.featureName[1] and feature.featureName[1].name then
            featurePortrayal:AddInstructions('LocalOffset:3.51,0;TextAlignVertical:Center;FontSize:10;FontColor:CHCOR')
            featurePortrayal:AddTextInstruction(EncodeString(GetFeatureName(feature, contextParameters)), 24, 21, viewingGroup, 24)
        end
    else
        error('Invalid primitive type or mariner settings passed to portrayal')
    end

    return viewingGroup
end