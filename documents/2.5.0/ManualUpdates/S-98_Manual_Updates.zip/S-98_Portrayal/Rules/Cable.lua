function Cable(feature, featurePortrayal, contextParameters)
    local viewingGroup
    
    if feature.PrimitiveType == PrimitiveType.Curve then    
        viewingGroup = 34070

        if contextParameters.RadarOverlay then
            featurePortrayal:AddInstructions('ViewingGroup:34070;DrawingPriority:18;DisplayPlane:OverRadar')
        else
            featurePortrayal:AddInstructions('ViewingGroup:34070;DrawingPriority:18;DisplayPlane:UnderRadar')
        end
        
        featurePortrayal:SimpleLineStyle('dash',0.32,'CHCOR')
        featurePortrayal:AddInstructions('LineInstruction:_simple_')

        if feature.featureName[1] and feature.featureName[1].name then
            featurePortrayal:AddInstructions('LocalOffset:3.51,0;TextAlignVertical:Center;FontSize:10;FontColor:CHCOR')
            featurePortrayal:AddTextInstruction(EncodeString(GetFeatureName(feature, contextParameters)), 24, 21, viewingGroup, 24)
        end
    else
        error('Invalid primitive type or mariner settings passed to portrayal')
    end

    return viewingGroup
end