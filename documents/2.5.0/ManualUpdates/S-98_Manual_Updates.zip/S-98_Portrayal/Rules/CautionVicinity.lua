function CautionVicinity(feature, featurePortrayal, contextParameters)
    local viewingGroup
    
    if feature.PrimitiveType == PrimitiveType.Point then    
        viewingGroup = 26150

        if contextParameters.RadarOverlay then
            featurePortrayal:AddInstructions('ViewingGroup:26150;DrawingPriority:12;DisplayPlane:OverRadar')
        else
            featurePortrayal:AddInstructions('ViewingGroup:26150;DrawingPriority:12;DisplayPlane:UnderRadar')
        end
        
        featurePortrayal:AddInstructions('PointInstruction:CHINFO08')

        if feature.featureName[1] and feature.featureName[1].name then
            featurePortrayal:AddInstructions('LocalOffset:3.51,0;TextAlignVertical:Center;FontSize:10;FontColor:CHCOR')
            featurePortrayal:AddTextInstruction(EncodeString(GetFeatureName(feature, contextParameters)), 24, 21, viewingGroup, 24)
        end
    else
        error('Invalid primitive type or mariner settings passed to portrayal')
    end

    return viewingGroup
end