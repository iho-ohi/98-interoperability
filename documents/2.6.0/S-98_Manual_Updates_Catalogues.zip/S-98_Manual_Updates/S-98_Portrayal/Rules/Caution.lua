function Caution(feature, featurePortrayal, contextParameters)
    local viewingGroup

    if feature.PrimitiveType == PrimitiveType.Surface then
        viewingGroup = 26150

        featurePortrayal:AddInstructions('ViewingGroup:26150;DrawingPriority:15;DisplayPlane:UnderRadar')

        featurePortrayal:SimpleLineStyle('dash',0.32,'CHCOR')
        featurePortrayal:AddInstructions('LineInstruction:_simple_')

        if feature.featureName[1] and feature.featureName[1].name then
            featurePortrayal:AddInstructions('LocalOffset:3.51,0;TextAlignVertical:Center;FontSize:10;FontColor:CHCOR')
            featurePortrayal:AddTextInstruction(EncodeString(GetFeatureName(feature, contextParameters)), 24, 21, viewingGroup, 24)
        end

        featurePortrayal:AddInstructions('AlertReference:ProhAre')
    else
        error('Invalid primitive type or mariner settings passed to portrayal')
    end

    return viewingGroup
end