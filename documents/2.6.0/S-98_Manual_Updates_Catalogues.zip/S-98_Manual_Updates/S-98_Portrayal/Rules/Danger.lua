function Danger(feature, featurePortrayal, contextParameters)
    local viewingGroup

    if feature.PrimitiveType == PrimitiveType.Curve then
        viewingGroup = 12410

        if contextParameters.RadarOverlay then
            featurePortrayal:AddInstructions('ViewingGroup:12410;DrawingPriority:12;DisplayPlane:OverRadar')
        else
            featurePortrayal:AddInstructions('ViewingGroup:12410;DrawingPriority:12;DisplayPlane:UnderRadar')
        end

        featurePortrayal:SimpleLineStyle('dash',0.64,'DNGHL')
        featurePortrayal:AddInstructions('LineInstruction:_simple_')

        if feature.featureName[1] and feature.featureName[1].name then
            featurePortrayal:AddInstructions('LocalOffset:3.51,0;TextAlignVertical:Center;FontSize:10;FontColor:CHCOR')
            featurePortrayal:AddTextInstruction(EncodeString(GetFeatureName(feature, contextParameters)), 24, 21, viewingGroup, 24)
        end

        featurePortrayal:AddInstructions('AlertReference:NavHazard')
    else
        error('Invalid primitive type or mariner settings passed to portrayal')
    end

    return viewingGroup
end