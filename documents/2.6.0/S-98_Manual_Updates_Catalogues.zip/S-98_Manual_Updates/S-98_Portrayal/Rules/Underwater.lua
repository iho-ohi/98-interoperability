
function Underwater(feature, featurePortrayal, contextParameters)
    local viewingGroup

    if feature.PrimitiveType == PrimitiveType.Point then
        viewingGroup = 34050

        if contextParameters.RadarOverlay then
            featurePortrayal:AddInstructions('ViewingGroup:34050;DrawingPriority:12;DisplayPlane:OverRadar')
        else
            featurePortrayal:AddInstructions('ViewingGroup:34050;DrawingPriority:12;DisplayPlane:UnderRadar')
        end

        featurePortrayal:AddInstructions('PointInstruction:POSGEN01')

        if feature.featureName[1] and feature.featureName[1].name then
            featurePortrayal:AddInstructions('LocalOffset:3.51,0;TextAlignVertical:Center;FontSize:10;FontColor:CHCOR')
            featurePortrayal:AddTextInstruction(EncodeString(GetFeatureName(feature, contextParameters)), 24, 21, viewingGroup, 24)
        end

        if feature.valueOfSounding and feature.valueOfSounding <= contextParameters.SafetyContour then
		    featurePortrayal:AddInstructions('AlertReference:NavHazard')
        end
    else
        error('Invalid primitive type or mariner settings passed to portrayal')
    end

	return viewingGroup
end