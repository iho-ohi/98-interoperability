function Other(feature, featurePortrayal, contextParameters)
    local viewingGroup
    
    if feature.PrimitiveType == PrimitiveType.Point then
        viewingGroup = 12410
        
        featurePortrayal:AddInstructions('ViewingGroup:12410;DrawingPriority:12;DisplayPlane:UnderRadar')        
        featurePortrayal:AddInstructions('PointInstruction:POSGEN04')

        
        if feature.featureName[1] and feature.featureName[1].name then
            featurePortrayal:AddInstructions('LocalOffset:3.51,0;TextAlignVertical:Center;FontSize:10;FontColor:CHCOR')
            featurePortrayal:AddTextInstruction(EncodeString(GetFeatureName(feature, contextParameters)), 24, 21, viewingGroup, 24)
        end

    elseif feature.PrimitiveType == PrimitiveType.Curve then    
        viewingGroup = 12410

        featurePortrayal:AddInstructions('ViewingGroup:12410;DrawingPriority:12;DisplayPlane:UnderRadar')
        
        featurePortrayal:SimpleLineStyle('solid',0.32,'DNGHL')
        featurePortrayal:AddInstructions('LineInstruction:_simple_')

        if feature.featureName[1] and feature.featureName[1].name then
            featurePortrayal:AddInstructions('LocalOffset:3.51,0;TextAlignVertical:Center;FontSize:10;FontColor:CHCOR')
            featurePortrayal:AddTextInstruction(EncodeString(GetFeatureName(feature, contextParameters)), 24, 21, viewingGroup, 24)
        end
    elseif feature.PrimitiveType == PrimitiveType.Surface then
        viewingGroup = 12410

        featurePortrayal:AddInstructions('ViewingGroup:12410;DrawingPriority:12;DisplayPlane:UnderRadar')
        featurePortrayal:AddInstructions ('ColorFill:CHCOR,0.5')

        if feature.featureName[1] and feature.featureName[1].name then
            featurePortrayal:AddInstructions('LocalOffset:3.51,0;TextAlignVertical:Center;FontSize:10;FontColor:CHCOR')
            featurePortrayal:AddTextInstruction(EncodeString(GetFeatureName(feature, contextParameters)), 24, 21, viewingGroup, 24)
        end
    else
        error('Invalid primitive type or mariner settings passed to portrayal')
    end

    return viewingGroup
end